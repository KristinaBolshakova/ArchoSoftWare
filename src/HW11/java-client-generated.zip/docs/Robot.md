# Robot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**model** | **String** |  | 
**version** | **String** |  | 
**charge** | **Long** |  | 
**garbageContainer** | **Long** |  | 
**robotPollution** | **Long** |  | 
**nextService** | **Long** |  | 
**serialNumber** | **String** |  | 
**ipAddress** | **Long** |  | 
**groupId** | **Long** |  | 
