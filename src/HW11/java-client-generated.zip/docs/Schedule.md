# Schedule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**dateTime** | **String** |  | 
**mode** | **Long** |  | 
**robotId** | **Long** |  | 
