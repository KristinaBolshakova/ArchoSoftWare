# Resources

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OS** | [**OSEnum**](#OSEnum) | Операционная система сервера | 
**RAM** | **String** |  | 
**HDD** | **String** |  | 
**CPU** | **String** |  | 

<a name="OSEnum"></a>
## Enum: OSEnum
Name | Value
---- | -----
WINDOWS | &quot;Windows&quot;
LINUX | &quot;Linux&quot;
