package io.swagger.server.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.vertx.core.json.JsonObject;
import io.vertx.codegen.annotations.DataObject;
/**
 * Resources
 */

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaVertXServerCodegen", date = "2023-08-05T14:53:44.405133603Z[GMT]")



public class Resources   {
  /**
   * Операционная система сервера
   */
  public enum OSEnum {
    WINDOWS("Windows"),
    LINUX("Linux");

    private String value;

    OSEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static OSEnum fromValue(String value) {
      for (OSEnum b : OSEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      return null;
    }

  }
  private OSEnum OS = null;

  private String RAM = null;

  private String HDD = null;

  private String CPU = null;

  public Resources OS(OSEnum OS) {
    this.OS = OS;
    return this;
  }

  /**
   * Операционная система сервера
   * @return OS
   **/
    public OSEnum getOS() {
    return OS;
  }

  public void setOS(OSEnum OS) {
    this.OS = OS;
  }

  public Resources RAM(String RAM) {
    this.RAM = RAM;
    return this;
  }

  /**
   * Get RAM
   * @return RAM
   **/
    public String getRAM() {
    return RAM;
  }

  public void setRAM(String RAM) {
    this.RAM = RAM;
  }

  public Resources HDD(String HDD) {
    this.HDD = HDD;
    return this;
  }

  /**
   * Get HDD
   * @return HDD
   **/
    public String getHDD() {
    return HDD;
  }

  public void setHDD(String HDD) {
    this.HDD = HDD;
  }

  public Resources CPU(String CPU) {
    this.CPU = CPU;
    return this;
  }

  /**
   * Get CPU
   * @return CPU
   **/
    public String getCPU() {
    return CPU;
  }

  public void setCPU(String CPU) {
    this.CPU = CPU;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Resources resources = (Resources) o;
    return Objects.equals(this.OS, resources.OS) &&
        Objects.equals(this.RAM, resources.RAM) &&
        Objects.equals(this.HDD, resources.HDD) &&
        Objects.equals(this.CPU, resources.CPU);
  }

  @Override
  public int hashCode() {
    return Objects.hash(OS, RAM, HDD, CPU);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Resources {\n");
    
    sb.append("    OS: ").append(toIndentedString(OS)).append("\n");
    sb.append("    RAM: ").append(toIndentedString(RAM)).append("\n");
    sb.append("    HDD: ").append(toIndentedString(HDD)).append("\n");
    sb.append("    CPU: ").append(toIndentedString(CPU)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
